//========= Copyright ?1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================

#include<VGUI_Layout.h>

using namespace vgui;

Layout::Layout()
{
}

/*void Layout::setPanel(Panel* panel)
{
}*/

void Layout::performLayout(Panel* panel)
{
}
